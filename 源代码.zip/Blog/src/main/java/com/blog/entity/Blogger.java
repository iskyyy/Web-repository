/*  1:   */ package com.blog.entity;
/*  2:   */ 
/*  3:   */ public class Blogger
/*  4:   */ {
/*  5:   */   private Integer id;
/*  6:   */   private String userName;
/*  7:   */   private String password;
/*  8:   */   private String nickName;
/*  9:   */   private String sign;
/* 10:   */   private String proFile;
/* 11:   */   private String imageName;
/* 12:   */   
/* 13:   */   public Integer getId()
/* 14:   */   {
/* 15:19 */     return this.id;
/* 16:   */   }
/* 17:   */   
/* 18:   */   public void setId(Integer id)
/* 19:   */   {
/* 20:22 */     this.id = id;
/* 21:   */   }
/* 22:   */   
/* 23:   */   public String getUserName()
/* 24:   */   {
/* 25:25 */     return this.userName;
/* 26:   */   }
/* 27:   */   
/* 28:   */   public void setUserName(String userName)
/* 29:   */   {
/* 30:28 */     this.userName = userName;
/* 31:   */   }
/* 32:   */   
/* 33:   */   public String getPassword()
/* 34:   */   {
/* 35:31 */     return this.password;
/* 36:   */   }
/* 37:   */   
/* 38:   */   public void setPassword(String password)
/* 39:   */   {
/* 40:34 */     this.password = password;
/* 41:   */   }
/* 42:   */   
/* 43:   */   public String getNickName()
/* 44:   */   {
/* 45:37 */     return this.nickName;
/* 46:   */   }
/* 47:   */   
/* 48:   */   public void setNickName(String nickName)
/* 49:   */   {
/* 50:40 */     this.nickName = nickName;
/* 51:   */   }
/* 52:   */   
/* 53:   */   public String getSign()
/* 54:   */   {
/* 55:43 */     return this.sign;
/* 56:   */   }
/* 57:   */   
/* 58:   */   public void setSign(String sign)
/* 59:   */   {
/* 60:46 */     this.sign = sign;
/* 61:   */   }
/* 62:   */   
/* 63:   */   public String getProFile()
/* 64:   */   {
/* 65:49 */     return this.proFile;
/* 66:   */   }
/* 67:   */   
/* 68:   */   public void setProFile(String proFile)
/* 69:   */   {
/* 70:52 */     this.proFile = proFile;
/* 71:   */   }
/* 72:   */   
/* 73:   */   public String getImageName()
/* 74:   */   {
/* 75:55 */     return this.imageName;
/* 76:   */   }
/* 77:   */   
/* 78:   */   public void setImageName(String imageName)
/* 79:   */   {
/* 80:58 */     this.imageName = imageName;
/* 81:   */   }
/* 82:   */ }


/* Location:           D:\classes\
 * Qualified Name:     com.blog.entity.Blogger
 * JD-Core Version:    0.7.0.1
 */