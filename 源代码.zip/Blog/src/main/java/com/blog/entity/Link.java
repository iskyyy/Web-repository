/*  1:   */ package com.blog.entity;
/*  2:   */ 
/*  3:   */ public class Link
/*  4:   */ {
/*  5:   */   private Integer id;
/*  6:   */   private String linkName;
/*  7:   */   private String linkUrl;
/*  8:   */   private Integer orderNo;
/*  9:   */   
/* 10:   */   public Integer getId()
/* 11:   */   {
/* 12:16 */     return this.id;
/* 13:   */   }
/* 14:   */   
/* 15:   */   public void setId(Integer id)
/* 16:   */   {
/* 17:19 */     this.id = id;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public String getLinkName()
/* 21:   */   {
/* 22:22 */     return this.linkName;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public void setLinkName(String linkName)
/* 26:   */   {
/* 27:25 */     this.linkName = linkName;
/* 28:   */   }
/* 29:   */   
/* 30:   */   public String getLinkUrl()
/* 31:   */   {
/* 32:28 */     return this.linkUrl;
/* 33:   */   }
/* 34:   */   
/* 35:   */   public void setLinkUrl(String linkUrl)
/* 36:   */   {
/* 37:31 */     this.linkUrl = linkUrl;
/* 38:   */   }
/* 39:   */   
/* 40:   */   public Integer getOrderNo()
/* 41:   */   {
/* 42:34 */     return this.orderNo;
/* 43:   */   }
/* 44:   */   
/* 45:   */   public void setOrderNo(Integer orderNo)
/* 46:   */   {
/* 47:37 */     this.orderNo = orderNo;
/* 48:   */   }
/* 49:   */ }


/* Location:           D:\classes\
 * Qualified Name:     com.blog.entity.Link
 * JD-Core Version:    0.7.0.1
 */